https://dex6354.github.io/MeuTreino/

Edição de Abas Aprimorada:

Agora, no modo de edição, apenas o nome da aba atualmente ativa se torna um campo de texto editável, e somente após um segundo clique sobre ela.
quando clicar em outra aba ( abc) ela ainda permaneça no modo de edição só que na outra aba, e só depois que eu clicar de novo no titulo da aba o nome da aba atualmente ativa se torna um campo de texto editável.

Lógica de Autocomplete Otimizada:

Debounce (Atraso Inteligente): A busca por exercícios agora acontece apenas 100ms depois que você para de digitar, tornando a resposta quase instantânea.

Busca Mínima: A pesquisa é ativada a partir do primeiro caractere digitado (1), agilizando a localização de exercícios.

Limite de Resultados: O limite de 15 sugestões foi removido. Agora, todos os resultados que correspondem à sua busca serão exibidos na lista.

no modo de edição, se eu clicar em cima da imagem do exercício, abra um modal com o campo para editar o link da imagem do exercício
