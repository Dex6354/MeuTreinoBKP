https://dex6354.github.io/MeuTreinoV4/

Debounce (Atraso Inteligente): A busca só acontece 300ms depois que você para de digitar.

Busca Mínima: A busca só é ativada quando você digita 2 ou mais caracteres, evitando buscas desnecessárias.

Limite de Resultados: A lista de sugestões agora mostra no máximo 15 resultados, tornando a exibição muito mais leve e rápida.

Renderização Eficiente: Em vez de criar os elementos um por um, o código agora monta todo o HTML da lista de sugestões e o insere na página de uma só vez, o que é muito mais rápido para o navegador.
