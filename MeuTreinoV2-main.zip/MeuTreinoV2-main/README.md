https://dex6354.github.io/MeuTreino/

V2 com json dentro do html
E adição de exercicios não abre mais um modal
