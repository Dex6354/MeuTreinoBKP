https://dex6354.github.io/MeuTreino/

V1 com pop up para adicionar treino
